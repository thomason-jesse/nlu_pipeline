package edu.cmu.sphinx.util.props;

public class AnotherDummyFrontEnd extends DummyFrontEnd {

}
